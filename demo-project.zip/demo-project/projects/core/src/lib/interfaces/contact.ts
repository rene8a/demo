export interface Contact {
  id?: number;
  fullName?: string;
  phone?: string;
  email?: string;
}
