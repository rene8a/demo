export enum ButtonType {
  warning,
  info,
  normal,
  icon
}
