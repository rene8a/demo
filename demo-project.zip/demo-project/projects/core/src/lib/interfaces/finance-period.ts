export interface FinancePeriod {
  id?: number;
  periodType?: string;
  periodValue?: string;
  amount?: number;
}
