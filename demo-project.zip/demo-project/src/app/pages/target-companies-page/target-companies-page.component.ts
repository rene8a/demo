import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-target-companies-page',
  templateUrl: './target-companies-page.component.html',
  styleUrls: ['./target-companies-page.component.css']
})
export class TargetCompaniesPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
