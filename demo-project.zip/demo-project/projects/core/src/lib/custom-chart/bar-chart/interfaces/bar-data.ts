export interface BarData {
  xValue: string;
  yFrequency: number;
}
