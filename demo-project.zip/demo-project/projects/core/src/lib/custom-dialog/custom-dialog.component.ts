import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-custom-dialog',
  templateUrl: './custom-dialog.component.html',
  styleUrls: ['./custom-dialog.component.css']
})
export class CustomDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
