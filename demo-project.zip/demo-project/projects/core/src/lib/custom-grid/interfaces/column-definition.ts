export interface ColumnDefinition {
  columnDef: string;
  header: string;
  cell: any;
}
